class Config:
    SQLALCHEMY_DATABASE_URI = 'sqlite:///comments.db'
    SQLALCHEMY_TRACK_MODIFICATIONS = False
