from flask import Flask, request, jsonify
from models import db, Comment
from config import Config

app = Flask(__name__)
app.config.from_object(Config)

# Initialiser la base de données
db.init_app(app)

# Route pour la page d'accueil
@app.route('/')
def home():
    return jsonify({'message': 'Welcome to the Comment Management API!'})

# Ajouter un commentaire
@app.route('/comments', methods=['POST'])
def add_comment():
    data = request.get_json()
    user_id = data.get('user_id')
    course_id = data.get('course_id')
    content = data.get('content')
    rating = data.get('rating', 0)
    reactions = ','.join(data.get('reactions', []))

    new_comment = Comment(user_id=user_id, course_id=course_id, content=content, rating=rating, reactions=reactions)

    db.session.add(new_comment)
    db.session.commit()

    return jsonify({'id': new_comment.id, 'message': 'Comment added successfully'}), 201

# Obtenir tous les commentaires d'un cours
@app.route('/courses/<int:course_id>/comments', methods=['GET'])
def get_comments(course_id):
    comments = Comment.query.filter_by(course_id=course_id).all()
    return jsonify([{
        'id': comment.id,
        'user_id': comment.user_id,
        'content': comment.content,
        'rating': comment.rating,
        'reactions': comment.reactions.split(',')
    } for comment in comments])

# Modifier un commentaire
@app.route('/comments/<int:id>', methods=['PUT'])
def update_comment(id):
    data = request.get_json()
    comment = Comment.query.get(id)

    if not comment:
        return jsonify({'message': 'Comment not found'}), 404

    comment.content = data.get('content', comment.content)
    comment.rating = data.get('rating', comment.rating)
    comment.reactions = ','.join(data.get('reactions', comment.reactions.split(',')))

    db.session.commit()

    return jsonify({'message': 'Comment updated successfully'})

# Supprimer un commentaire
@app.route('/comments/<int:id>', methods=['DELETE'])
def delete_comment(id):
    comment = Comment.query.get(id)

    if not comment:
        return jsonify({'message': 'Comment not found'}), 404

    db.session.delete(comment)
    db.session.commit()

    return jsonify({'message': 'Comment deleted successfully'})
@app.route('/comments/<int:id>/react', methods=['POST'])
def react_to_comment(id):
    comment = Comment.query.get(id)
    if not comment:
        return jsonify({'message': 'Comment not found'}), 404

    data = request.get_json()
    new_reaction = data.get('reaction')

    if not new_reaction:
        return jsonify({'message': 'No reaction provided'}), 400

    current_reactions = comment.reactions.split(',') if comment.reactions else []
    current_reactions.append(new_reaction)
    comment.reactions = ','.join(current_reactions)

    db.session.commit()

    return jsonify({'message': f'Reaction "{new_reaction}" added to comment {id}.'})


# Créer la base de données (si elle n'existe pas déjà) avant de démarrer le serveur
if __name__ == '__main__':
    with app.app_context():  # Crée le contexte d'application nécessaire pour interagir avec la base de données
        db.create_all()  # Crée les tables de la base de données

    app.run(debug=True)  # Lancer l'application Flask
