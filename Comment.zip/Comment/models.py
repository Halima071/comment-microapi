from flask_sqlalchemy import SQLAlchemy

db = SQLAlchemy()

class Comment(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, nullable=False)
    course_id = db.Column(db.Integer, nullable=False)
    content = db.Column(db.String(500), nullable=False)
    rating = db.Column(db.Integer, default=0)  # Rating de 0 à 5
    reactions = db.Column(db.String(100), default='')  # Ex: 'like,heart'

    def __repr__(self):
        return f'<Comment {self.id}>'
